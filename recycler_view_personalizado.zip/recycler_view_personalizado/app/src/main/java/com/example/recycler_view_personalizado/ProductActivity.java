package com.example.recycler_view_personalizado;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import android.app.Activity;
import android.os.Bundle;



public class ProductActivity extends AppCompatActivity {

    ArrayList<Personaje> arrayList_personajes;
    RecyclerView recyclerView_personajes;
    AdaptadorPersonal adaptadorPersonaje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        arrayList_personajes = new ArrayList<>();


        recyclerView_personajes = findViewById(R.id.id_ap_recyclerview_productos);
        recyclerView_personajes.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        recyclerView_personajes.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        llenarPersonajes();
        adaptadorPersonaje = new AdaptadorPersonal(arrayList_personajes);
        recyclerView_personajes.setAdapter(adaptadorPersonaje);
    }

   private void llenarPersonajes() {
       arrayList_personajes.add(new Personaje("Pastel de Manzana", "10 Porciones / $ 45.000", R.drawable.pastel2pisos));
       arrayList_personajes.add(new Personaje("Pastel de Cereza", "2 Porciones / $ 25.000", R.drawable.pastelcereza));
       arrayList_personajes.add(new Personaje("Pastel de Chispas", "3 Porciones / $ 35.000", R.drawable.pastelchispas));
       arrayList_personajes.add(new Personaje("Pastel de Chocolate", "12 Porciones / $ 80.000", R.drawable.pastelchocolate));
       arrayList_personajes.add(new Personaje("Pastel de Limon", "4 Porciones / $ 38.000", R.drawable.pastellimon));
       arrayList_personajes.add(new Personaje("Pastel mini", "5 Porciones / $ 52.000", R.drawable.pastelmini));
       arrayList_personajes.add(new Personaje("Pastel de Mora", "1 Porcion / $ 18.000", R.drawable.pastelmora));
       arrayList_personajes.add(new Personaje("Pastel de Naranja", "8 Porcion / $ 62.000", R.drawable.pastelnaranja));



   }

}
