package com.example.recycler_view_personalizado;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;


public class SucursalActivity extends AppCompatActivity {
    ArrayList<Personaje> arrayList_personajes;
    RecyclerView recyclerView_personajes;
    AdaptadorPersonal adaptadorPersonaje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sucursal);

        arrayList_personajes = new ArrayList<>();


        recyclerView_personajes = findViewById(R.id.id_as_recyclerview_sucursales);
        recyclerView_personajes.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        recyclerView_personajes.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        llenarPersonajes();
        adaptadorPersonaje = new AdaptadorPersonal(arrayList_personajes);
        recyclerView_personajes.setAdapter(adaptadorPersonaje);


    }

    private void llenarPersonajes() {
        arrayList_personajes.add(new Personaje("Sucursales", "Conoce nuestras sucursales", R.drawable.sucursales));
        arrayList_personajes.add(new Personaje("Sucursal Bosa", "Visitanos!!", R.drawable.sucursalbosa));
        arrayList_personajes.add(new Personaje("Sucursal Chapinero", "Visitanos!!", R.drawable.sucursalchapinero));
        arrayList_personajes.add(new Personaje("Sucursal Chia", "Visitanos!!", R.drawable.sucursalchia));
        arrayList_personajes.add(new Personaje("Sucursal Engativa", "Visitanos!!", R.drawable.sucursalengativa));
        arrayList_personajes.add(new Personaje("Sucursal Fontibon", "Visitanos!!", R.drawable.sucursalfontibon));
    }
}
