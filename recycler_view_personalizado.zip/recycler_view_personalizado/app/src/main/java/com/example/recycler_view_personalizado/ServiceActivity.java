package com.example.recycler_view_personalizado;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;


public class ServiceActivity extends AppCompatActivity {

    ArrayList<Personaje> arrayList_personajes;
    RecyclerView recyclerView_personajes;
    AdaptadorPersonal adaptadorPersonaje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service);

        arrayList_personajes = new ArrayList<>();


        recyclerView_personajes = findViewById(R.id.id_as_recyclerview_service);
        recyclerView_personajes.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        recyclerView_personajes.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        llenarPersonajes();
        adaptadorPersonaje = new AdaptadorPersonal(arrayList_personajes);
        recyclerView_personajes.setAdapter(adaptadorPersonaje);
    }

    private void llenarPersonajes() {
        arrayList_personajes.add(new Personaje("Atencion al cliente", "Brindamos atencion personalizada 24/7", R.drawable.atencion));
        arrayList_personajes.add(new Personaje("Entrega a domicilio", "Solicita tus pedidos a cualquier ciudad", R.drawable.domicilio));
        arrayList_personajes.add(new Personaje("Metodos de pago", "Realiza pagos en medio fisico o digital", R.drawable.pagos));
        arrayList_personajes.add(new Personaje("Asesoria", "Te asesoramos en tu eleccion de postre", R.drawable.asesoria));
        arrayList_personajes.add(new Personaje("Parqueadero", "Instalaciones con parqueo gratis", R.drawable.parqueo));
        arrayList_personajes.add(new Personaje("Taxi", "Servicio de taxi confiable", R.drawable.taxi));

    }
}
